/*
 * $Id: utils.c,v 1.1.1.1 2002/02/03 14:01:43 flv Exp $
 *
 * Author: Flavio Mendes <flv@void.com.br>
 */

#include "hmix.h"

unsigned int convert_vol(const char *conv_vol)
{
	char *tok;

    	if ((tok = strchr(conv_vol, ':'))) 
		return atoi(conv_vol) + (256 * atoi(tok + 1));
	else
	   	return atoi(conv_vol) + (256 * atoi(conv_vol));
}

int get_vol(int fd, int flag, void *get_out)
{
    	unsigned int volume;

    	if (ioctl(fd, flag, &volume) < 0)
		return 0;
  
    	sprintf(get_out, "%d:%d", (volume & LEFT_MASK), 
	     	(volume & RIGHT_MASK) >> 8);

    	return 1;
}	   

int set_vol(int fd, int flag, int volume)
{
    	return ioctl(fd, flag, &volume);
}

int get_eq(int fd, int flag, void *eq)
{
	if (ioctl(fd, flag, &eq) < 0)
	   	return 0;

	return 1; 
}

int set_eq(int fd, int flag, int eq)
{
   	return ioctl(fd, flag, &eq);
}

