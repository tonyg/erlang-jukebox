/*
 * $Id: main.c,v 1.1.1.1 2002/02/03 14:01:43 flv Exp $
 *
 * Author: Flavio Mendes <flv@void.com.br>
 */

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <errno.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h>
#include <sys/ioctl.h>
#include <linux/soundcard.h> 
#include "hmix.h"

static const opt opts[] = {
   	{"-master", "MASTER", SOUND_MIXER_READ_VOLUME, SOUND_MIXER_WRITE_VOLUME,
		get_vol, set_vol},
   	{"-cd",	    "CD",     SOUND_MIXER_READ_CD,     SOUND_MIXER_WRITE_CD,
		get_vol, set_vol},
   	{"-mic",    "MIC",    SOUND_MIXER_READ_MIC,    SOUND_MIXER_WRITE_MIC,
		get_vol, set_vol},
   	{"-synth",  "SYNTH",  SOUND_MIXER_READ_SYNTH,  SOUND_MIXER_WRITE_SYNTH, 
		get_vol, set_vol},
   	{"-pcm",    "PCM",    SOUND_MIXER_READ_PCM,    SOUND_MIXER_WRITE_PCM, 
		get_vol, set_vol},
   	{"-line",   "LINE",   SOUND_MIXER_READ_LINE,   SOUND_MIXER_WRITE_LINE, 
		get_vol, set_vol},
   	{"-line1",  "LINE1",  SOUND_MIXER_READ_LINE1,  SOUND_MIXER_WRITE_LINE1, 
		get_vol, set_vol},
   	{"-line2",  "LINE2",  SOUND_MIXER_READ_LINE2,  SOUND_MIXER_WRITE_LINE2, 
		get_vol, set_vol},
   	{"-bass",   "BASS",   SOUND_MIXER_READ_BASS,   SOUND_MIXER_WRITE_BASS, 
		get_eq, set_eq},
   	{"-treble", "TREBLE", SOUND_MIXER_READ_TREBLE, SOUND_MIXER_WRITE_TREBLE,
		get_eq, set_eq},
};

static const unsigned short int opts_size = sizeof(opts) / sizeof(opt);

void usage(char *prog)
{
   	unsigned int i;

	fprintf(stderr, "usage: %s [", prog);

	for (i = 0; i <= opts_size; i++)
	   	fprintf(stderr, "%s%s", opts[i].arg, 
		      	((i < opts_size - 1) ? "|" : ""));

	fprintf(stderr, "] L:R\n");

    	fprintf(stderr, "eg: %s -mic 80:70\n", prog);
    	fprintf(stderr, "or\n");
    	fprintf(stderr, "eg: %s -mic 80\n", prog);
	
	exit(-1);
}

int main(int argc, char **argv)
{
    	int mix;
	int tosco = 0;
    	unsigned int vol;
	unsigned int i;
    	char buffer[1024];

    	if ((mix = open("/dev/mixer", O_RDWR)) == -1) {
		fprintf(stderr, "Can't open() /dev/mixer!: %s\n", 
		      	strerror(errno));
		exit(-1);
    	}
	
	if (argc == 1) {
		for (i = 0; i < opts_size; i++) 
			if (opts[i].get(mix, opts[i].read_flags, buffer))
				fprintf(stdout, "%s:\t%s\n", opts[i].name, 
				      	buffer);
    	} else if (argc == 3) {
	    	if ((vol = convert_vol(argv[2])) < 0)
			usage(argv[0]);
		
		for (i = 0; i < opts_size; i++) {
		   	if (!strcmp(argv[1], opts[i].arg)) {
			   	opts[i].set(mix, opts[i].write_flags, vol);
				tosco = 1;
			}
		}

		if (!tosco)
		   	usage(argv[0]);
		
    	} else usage(argv[0]);
	   
    return 0;
}
