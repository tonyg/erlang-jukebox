/*
 * $Id: hmix.h,v 1.1.1.1 2002/02/03 14:01:43 flv Exp $
 *
 * Author: Flavio Mendes <flv@void.com.br>
 */

#ifndef _HMIX_H
#define _HMIX_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>

enum {
	MAX_OPT_SIZE = 1024,
	LEFT_MASK = 0x00ff,
	RIGHT_MASK = 0xff00
};

typedef struct {
   	char arg[MAX_OPT_SIZE];
	char name[MAX_OPT_SIZE];
	int read_flags;
	int write_flags;
	int (*get)(int fd, int flag, void *get_out);
	int (*set)(int fd, int flag, int volume);
} opt;

extern unsigned int convert_vol(const char *conv_vol);
extern int get_vol(int fd, int flag, void *get_out);
extern int set_vol(int fd, int flag, int volume);
extern int get_eq(int fd, int flag, void *eq);
extern int set_eq(int fd, int flag, int eq);



#endif /* hmix.h */
